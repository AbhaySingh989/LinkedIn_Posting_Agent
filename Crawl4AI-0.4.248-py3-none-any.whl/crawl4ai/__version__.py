# crawl4ai/_version.py
# __version__ = "0.4.3b3"
__version__ = "0.4.248"
